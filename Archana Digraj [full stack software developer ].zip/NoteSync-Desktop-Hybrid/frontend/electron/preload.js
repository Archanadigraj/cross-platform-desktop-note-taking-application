import { contextBridge, ipcRenderer } from 'electron'

contextBridge.exposeInMainWorld('electronAPI', {
  toggleCompact: () => ipcRenderer.invoke('toggle-compact')
})
