import axios from 'axios'
import useAuth from './store.js'

const baseURL = 'http://localhost:8000'
const api = axios.create({ baseURL })

api.interceptors.request.use((config) => {
  const { accessToken } = useAuth.getState()
  if (accessToken) config.headers.Authorization = `Bearer ${accessToken}`
  return config
})

// auto-refresh access token on 401
api.interceptors.response.use(
  r => r,
  async (error) => {
    const original = error.config
    if (error.response?.status === 401 && !original._retry) {
      original._retry = true
      try {
        const { refreshToken } = useAuth.getState()
        if (!refreshToken) throw new Error('no refresh')
        const resp = await axios.post(`${baseURL}/api/auth/refresh`, { refreshToken })
        useAuth.getState().setPrefs({ accessToken: resp.data.accessToken, refreshToken: resp.data.refreshToken })
        original.headers.Authorization = `Bearer ${resp.data.accessToken}`
        return api(original)
      } catch {
        useAuth.getState().logout()
      }
    }
    throw error
  }
)

export default api
