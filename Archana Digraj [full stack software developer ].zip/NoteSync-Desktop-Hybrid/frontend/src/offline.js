import localforage from 'localforage'

localforage.config({ name: 'notesync' })
const store = localforage.createInstance({ name: 'notesync', storeName: 'notes' })

export async function cacheNotes(items) {
  await store.setItem('list', items || [])
}
export async function getCachedNotes() {
  return (await store.getItem('list')) || []
}
export async function queuePending(note) {
  const q = (await store.getItem('queue')) || []
  q.push(note)
  await store.setItem('queue', q)
}
export async function popQueue() {
  const q = (await store.getItem('queue')) || []
  if (!q.length) return null
  const n = q.shift()
  await store.setItem('queue', q)
  return n
}
