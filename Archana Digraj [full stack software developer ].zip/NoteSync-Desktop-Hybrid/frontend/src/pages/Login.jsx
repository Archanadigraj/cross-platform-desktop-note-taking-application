import React, { useState } from 'react'
import api from '../api.js'
import useAuth from '../store.js'
import { useNavigate } from 'react-router-dom'

export default function Login() {
  const nav = useNavigate()
  const [mode, setMode] = useState('login')
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState(null)
  const login = useAuth(s => s.login)
  const setPrefs = useAuth(s => s.setPrefs)

  const submit = async (e) => {
    e.preventDefault()
    setError(null)
    try {
      const url = mode === 'login' ? '/api/auth/login' : '/api/auth/signup'
      const resp = await api.post(url, { username, password })
      login(resp.data)
      setPrefs({ accessToken: resp.data.accessToken, refreshToken: resp.data.refreshToken })
      nav('/')
    } catch (e) {
      setError(e.response?.data?.error || 'Failed')
    }
  }

  return (
    <div style={{ display:'grid', placeItems:'center', height:'100vh', gap:16 }}>
      <h1>NoteSync</h1>
      <form onSubmit={submit} style={{ display:'grid', gap:8, width:300 }}>
        <input placeholder="Username" value={username} onChange={e=>setUsername(e.target.value)} />
        <input placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
        <button type="submit">{mode === 'login' ? 'Login' : 'Sign Up'}</button>
        <button type="button" onClick={()=>setMode(m=>m==='login'?'signup':'login')}>
          Switch to {mode==='login'?'Sign Up':'Login'}
        </button>
        {error && <div style={{ color:'red' }}>{error}</div>}
      </form>
    </div>
  )
}
