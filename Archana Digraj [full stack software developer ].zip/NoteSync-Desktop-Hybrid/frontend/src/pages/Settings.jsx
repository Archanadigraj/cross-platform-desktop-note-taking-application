import React from 'react'
import useAuth from '../store.js'
import { Link } from 'react-router-dom'

export default function Settings() {
  const { theme, fontSize, setPrefs, user, logout } = useAuth()
  return (
    <div style={{ padding:16, display:'grid', gap:12 }}>
      <h2>Settings</h2>
      <div>User: <b>{user?.username}</b></div>
      <label>Theme: 
        <select value={theme} onChange={e=>setPrefs({ theme: e.target.value })}>
          <option value="light">light</option>
          <option value="dark">dark</option>
        </select>
      </label>
      <label>Font size:
        <input type="number" value={fontSize} onChange={e=>setPrefs({ fontSize: parseInt(e.target.value,10)||16 })} />
      </label>
      <div style={{ display:'flex', gap:8 }}>
        <Link to="/"><button>Back</button></Link>
        <button onClick={logout}>Logout</button>
      </div>
    </div>
  )
}
