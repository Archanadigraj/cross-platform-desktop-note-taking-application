import React, { useEffect, useState, useRef } from 'react'
import api from '../api.js'
import useAuth from '../store.js'
import io from 'socket.io-client'
import { cacheNotes, getCachedNotes, queuePending, popQueue } from '../offline.js'
import { Link } from 'react-router-dom'

const socket = io('http://localhost:8000')

export default function Dashboard() {
  const { user } = useAuth()
  const [text, setText] = useState('')
  const [notes, setNotes] = useState([])
  const [cursor, setCursor] = useState(null)
  const [hasMore, setHasMore] = useState(true)
  const [status, setStatus] = useState('online')
  const [loading, setLoading] = useState(false)
  const scroller = useRef(null)

  useEffect(() => {
    // realtime updates
    socket.on(`note:new:${user.id}`, (n) => {
      setNotes(prev => [n, ...prev])
      cacheNotes([n, ...notes])
    })
    return () => socket.off(`note:new:${user.id}`)
  }, [user?.id, notes])

  useEffect(() => {
    // initial load & offline fallback
    (async () => {
      try {
        setLoading(true)
        const resp = await api.get('/api/notes?limit=20')
        setNotes(resp.data.items)
        setCursor(resp.data.nextCursor)
        setHasMore(resp.data.hasMore)
        cacheNotes(resp.data.items)
        setStatus('online')
      } catch {
        const cached = await getCachedNotes()
        setNotes(cached)
        setHasMore(false)
        setStatus('offline (cached)')
      } finally {
        setLoading(false)
      }
    })()
  }, [])

  useEffect(() => {
    // retry pending queue when online
    const id = setInterval(async () => {
      try {
        await api.get('/api/health')
        let n
        while ((n = await popQueue())) {
          await api.post('/api/notes', n)
        }
        setStatus('online')
      } catch {
        setStatus('offline (queued)')
      }
    }, 3000)
    return () => clearInterval(id)
  }, [])

  const submit = async () => {
    const payload = { text }
    try {
      await api.post('/api/notes', payload)
      setText('')
    } catch {
      // queue for later
      await queuePending(payload)
      setText('')
      setStatus('offline (queued)')
    }
  }

  const loadMore = async () => {
    if (!hasMore || loading) return
    setLoading(true)
    try {
      const resp = await api.get(`/api/notes?limit=20${cursor ? `&cursor=${cursor}` : ''}`)
      setNotes(prev => [...prev, ...resp.data.items])
      setCursor(resp.data.nextCursor)
      setHasMore(resp.data.hasMore)
      cacheNotes([...notes, ...resp.data.items])
    } finally {
      setLoading(false)
    }
  }

  // infinite scroll
  useEffect(() => {
    const el = scroller.current
    if (!el) return
    const onScroll = () => {
      if (el.scrollTop + el.clientHeight >= el.scrollHeight - 20) loadMore()
    }
    el.addEventListener('scroll', onScroll)
    return () => el.removeEventListener('scroll', onScroll)
  }, [scroller.current, cursor, hasMore, loading])

  const toggleSize = () => window.electronAPI?.toggleCompact()

  return (
    <div style={{ display:'grid', gridTemplateRows:'auto 1fr', height:'100vh' }}>
      <header style={{ display:'flex', gap:12, padding:12, alignItems:'center', borderBottom:'1px solid #ddd' }}>
        <b>NoteSync</b>
        <span style={{ marginLeft: 'auto' }}>Status: {status}</span>
        <button onClick={toggleSize}>Compact/Expand</button>
        <Link to="/settings"><button>Settings</button></Link>
      </header>
      <main style={{ display:'grid', gridTemplateRows:'auto 1fr', gap:12, padding:12 }}>
        <div style={{ display:'flex', gap:8 }}>
          <textarea rows="3" style={{ flex:1 }} value={text} onChange={e=>setText(e.target.value)} placeholder="Write a note..." />
          <button onClick={submit}>Add</button>
        </div>
        <div ref={scroller} style={{ overflow:'auto', border:'1px solid #eee', borderRadius:8, padding:8 }}>
          {notes.map(n => (
            <div key={n._id || n.id} style={{ padding:8, borderBottom:'1px dashed #eee' }}>
              <div style={{ fontSize:12, opacity:0.7 }}>{new Date(n.createdAt).toLocaleString()}</div>
              <div>{n.text}</div>
              {n.stats && <div style={{ fontSize:12, opacity:0.7 }}>words: {n.stats.words} chars: {n.stats.chars ?? '-'}</div>}
            </div>
          ))}
          {loading && <div>Loading…</div>}
          {!hasMore && <div style={{ textAlign:'center', padding:12 }}>No more notes</div>}
        </div>
      </main>
    </div>
  )
}
