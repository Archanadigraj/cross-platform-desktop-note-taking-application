import create from 'zustand'
import CryptoJS from 'crypto-js'

const KEY = 'notesync_prefs'
const SECRET = 'notesync_local_secret' // for demo only

const loadPrefs = () => {
  try {
    const enc = localStorage.getItem(KEY)
    if (!enc) return {}
    const bytes = CryptoJS.AES.decrypt(enc, SECRET)
    const str = bytes.toString(CryptoJS.enc.Utf8)
    return JSON.parse(str)
  } catch { return {} }
}
const savePrefs = (obj) => {
  const enc = CryptoJS.AES.encrypt(JSON.stringify(obj), SECRET).toString()
  localStorage.setItem(KEY, enc)
}

const useAuth = create((set, get) => ({
  user: null,
  accessToken: null,
  refreshToken: null,
  isAuthed: false,
  theme: 'light',
  fontSize: 16,
  ...loadPrefs(),
  setPrefs: (p) => { const next = { ...get(), ...p }; savePrefs({ theme: next.theme, fontSize: next.fontSize, lastUser: next.user?.username, accessToken: next.accessToken, refreshToken: next.refreshToken }); set(p) },
  login: (payload) => set({ user: payload.user, accessToken: payload.accessToken, refreshToken: payload.refreshToken, isAuthed: true }, false, 'login'),
  logout: () => { savePrefs({}); set({ user: null, accessToken: null, refreshToken: null, isAuthed: false }) },
}))

export default useAuth
