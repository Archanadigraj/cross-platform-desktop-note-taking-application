from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title="Note Analysis Service")

class TextIn(BaseModel):
    text: str

@app.get("/health")
def health():
    return {"ok": True}

@app.post("/analyze")
def analyze(body: TextIn):
    text = body.text or ""
    words = [w for w in text.strip().split() if w]
    chars = len(text)
    return {"words": len(words), "chars": chars}
