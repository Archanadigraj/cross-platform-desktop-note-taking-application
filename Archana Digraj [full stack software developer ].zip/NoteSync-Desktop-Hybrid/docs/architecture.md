# Architecture Overview

## High-Level
- **Electron + React** renderer talks to **Node.js** backend via REST + Socket.IO.
- **Node.js** persists users/notes to **MongoDB** and caches paginated reads in **Redis**.
- **Python (FastAPI)** microservice provides note analysis to enrich notes and a simple health endpoint.
- **Docker Compose** orchestrates MongoDB and Redis; you can also run Node and Python in containers.

## Data Flow
1. User logs in → Node issues JWT access + refresh.
2. Renderer stores tokens (encrypted at-rest) and uses access token for API calls.
3. Creating a note → Node calls Python `/analyze` → stores stats alongside note → invalidates Redis cache → emits Socket.IO realtime event.
4. Fetching notes → Node uses paginated query and 30s Redis caching.
5. Offline → Renderer shows cached notes (IndexedDB) and queues new notes for retry.

## Realtime
- Socket.IO channels: `note:new:<userId>` broadcast per-user (demo uses client-side filter).

## Security
- Password hashing via bcrypt.
- JWT rotation and refresh pathway.
- Encrypted local storage for tokens (CryptoJS).

## Packaging
- `electron-builder` creates a Windows installer. Running app does not require dev tools.
