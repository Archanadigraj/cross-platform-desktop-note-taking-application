import express from 'express';
import morgan from 'morgan';
import cors from 'cors';
import dotenv from 'dotenv';
import { createServer } from 'http';
import { Server } from 'socket.io';
import mongoose from 'mongoose';
import { createClient } from 'redis';
import authRouter from './src/routes/auth.js';
import notesRouter from './src/routes/notes.js';
import adminRouter from './src/routes/admin.js';

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

const httpServer = createServer(app);
const io = new Server(httpServer, { cors: { origin: "*" } });
app.set('io', io);

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/notesync';
const REDIS_URL = process.env.REDIS_URL || 'redis://localhost:6379';
const PORT = process.env.PORT || 8000;

// Mongo
mongoose.connect(MONGO_URI).then(() => {
    console.log('MongoDB connected');
}).catch(err => {
    console.error('Mongo error', err);
    process.exit(1);
});

// Redis
const redis = createClient({ url: REDIS_URL });
redis.on('error', err => console.error('Redis Client Error', err));
await redis.connect();
app.set('redis', redis);

// Routes
app.use('/api/auth', authRouter);
app.use('/api/notes', notesRouter);
app.use('/api/admin', adminRouter);

app.get('/api/health', (req, res) => res.json({ ok: true }));

io.on('connection', (socket) => {
    console.log('Socket connected', socket.id);
    socket.on('disconnect', () => console.log('Socket disconnected', socket.id));
});

httpServer.listen(PORT, () => {
    console.log(`Node backend listening on http://localhost:${PORT}`);
});
