import mongoose from 'mongoose';

const noteSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  text: { type: String, required: true },
  stats: { type: Object }, // populated by Python microservice (word count, etc.)
  createdAt: { type: Date, default: Date.now }
});

noteSchema.index({ userId: 1, createdAt: -1 });

export default mongoose.model('Note', noteSchema);
