import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import User from '../models/User.js';

const router = Router();

const ISSUE_TOKENS = (user) => {
  const access = jwt.sign({ id: user._id, username: user.username, role: user.role }, process.env.JWT_ACCESS_SECRET, { expiresIn: `${process.env.ACCESS_TTL_MINUTES || 15}m` });
  const refresh = jwt.sign({ id: user._id }, process.env.JWT_REFRESH_SECRET, { expiresIn: `${process.env.REFRESH_TTL_DAYS || 7}d` });
  return { access, refresh };
};

router.post('/signup', async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ error: 'username & password required' });
  const existing = await User.findOne({ username });
  if (existing) return res.status(400).json({ error: 'username already exists' });
  const passwordHash = await bcrypt.hash(password, 10);
  const user = await User.create({ username, passwordHash });
  const { access, refresh } = ISSUE_TOKENS(user);
  res.json({ user: { id: user._id, username: user.username, role: user.role }, accessToken: access, refreshToken: refresh });
});

router.post('/login', async (req, res) => {
  const { username, password } = req.body;
  const user = await User.findOne({ username });
  if (!user) return res.status(401).json({ error: 'invalid credentials' });
  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) return res.status(401).json({ error: 'invalid credentials' });
  const { access, refresh } = ISSUE_TOKENS(user);
  res.json({ user: { id: user._id, username: user.username, role: user.role }, accessToken: access, refreshToken: refresh });
});

router.post('/refresh', async (req, res) => {
  const { refreshToken } = req.body;
  if (!refreshToken) return res.status(400).json({ error: 'refreshToken required' });
  try {
    const payload = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET);
    const user = await User.findById(payload.id);
    if (!user) return res.status(401).json({ error: 'invalid refresh token' });
    const { access, refresh } = ISSUE_TOKENS(user);
    res.json({ accessToken: access, refreshToken: refresh });
  } catch (e) {
    return res.status(401).json({ error: 'invalid refresh token' });
  }
});

export default router;
