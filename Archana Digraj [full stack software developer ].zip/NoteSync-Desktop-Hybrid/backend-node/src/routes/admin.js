import { Router } from 'express';
import Note from '../models/Note.js';
import { authRequired, adminOnly } from '../middleware/auth.js';

const router = Router();

router.get('/notes', authRequired, adminOnly, async (req, res) => {
  const notes = await Note.find({}).sort({ createdAt: -1 }).limit(200).lean();
  res.json({ items: notes });
});

export default router;
