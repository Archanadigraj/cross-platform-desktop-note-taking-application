import { Router } from 'express';
import Note from '../models/Note.js';
import { authRequired } from '../middleware/auth.js';
import axios from 'axios';

const router = Router();

function cacheKey(userId, cursor, limit) {
  return `notes:${userId}:${cursor || 'start'}:${limit}`;
}

router.post('/', authRequired, async (req, res) => {
  const { text } = req.body;
  if (!text || !text.trim()) return res.status(400).json({ error: 'text required' });

  // call Python microservice to analyze note (non-blocking fallback on error)
  let stats = null;
  try {
    const PY = process.env.PYTHON_SERVICE_URL || 'http://localhost:8001';
    const resp = await axios.post(`${PY}/analyze`, { text });
    stats = resp.data;
  } catch (e) {
    stats = { words: text.split(/\s+/).filter(Boolean).length };
  }

  const note = await Note.create({ userId: req.user.id, text, stats });
  // Invalidate cached pages for this user
  const redis = req.app.get('redis');
  const keys = await redis.keys(`notes:${req.user.id}:*`);
  if (keys.length) await redis.del(keys);

  // Emit realtime to all sockets
  const io = req.app.get('io');
  io.emit(`note:new:${req.user.id}`, { id: note._id, text: note.text, stats: note.stats, createdAt: note.createdAt });

  res.status(201).json({ note });
});

// Pagination via "cursor" (last seen note _id) + limit
router.get('/', authRequired, async (req, res) => {
  const limit = Math.min(parseInt(req.query.limit || '20', 10), 50);
  const cursor = req.query.cursor || null;

  const redis = req.app.get('redis');
  const key = cacheKey(req.user.id, cursor, limit);
  const cached = await redis.get(key);
  if (cached) return res.json(JSON.parse(cached));

  const q = { userId: req.user.id };
  if (cursor) q._id = { $lt: cursor };

  const notes = await Note.find(q).sort({ _id: -1 }).limit(limit + 1).lean();
  const hasMore = notes.length > limit;
  const items = hasMore ? notes.slice(0, limit) : notes;
  const nextCursor = hasMore ? items[items.length - 1]._id : null;

  const payload = { items, nextCursor, hasMore };
  await redis.setEx(key, 30, JSON.stringify(payload)); // cache 30s
  res.json(payload);
});

export default router;
